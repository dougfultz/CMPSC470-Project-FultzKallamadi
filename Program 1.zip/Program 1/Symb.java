class Symb {
   private String name;
   Symb(String n) { name = n;}
   public String name() {return name;}
   public String toString() {return name;}
} // class Symb
