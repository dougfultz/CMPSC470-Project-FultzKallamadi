import java.io.*;
class P1 {
   public static void main(String args[]){
     System.out.println(
       "Project 1 test driver. Enter any of the following commands:\n"+
       "  (Command prefixes are allowed)\n"+
       "\tOpen (a new scope)\n"+
       "\tClose (innermost current scope)\n"+
       "\tQuit (test driver)\n"+
       "\tDump (contents of symbol table)\n"+
       "\tInsert (symbol,integer pair into symbol table)\n"+
       "\tLookup (lookup symbol in top scope)\n"+
       "\tGlobal (global lookup of symbol in symbol table)\n"+
     "");
    
      // Complete this
   } // main
} // class P1
