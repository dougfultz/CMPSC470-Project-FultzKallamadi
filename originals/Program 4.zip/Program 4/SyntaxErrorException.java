class SyntaxErrorException extends RuntimeException {
	// No content since syntax error msg has already been generated
	//  by syntax_error()
	static final long serialVersionUID = 1L;
}
