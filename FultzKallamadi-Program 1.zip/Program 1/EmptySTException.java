//Doug Fultz
//Sujay Kallamadi
//CMPSC470 - Compiler Construction

class EmptySTException extends Exception{
    //These two classes are empty. They are used to signal duplicate insertion and empty symbol tables errors.
}